<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/config/config.php';
require_once __DIR__ . '/../app/core/Router.php';

$router = new Router();
require_once __DIR__ . '/../routes/web.php';

$router->dispatch();
