<?php
$router->get('/', ['AuthController','loginForm']);
$router->get('/login', ['AuthController','loginForm']);
$router->post('/login', ['AuthController','login']);
$router->get('/dashboard', ['AuthController','dashboard']);
$router->get('/logout', ['AuthController','logout']);
$router->get('/estudiantes', ['EstudianteController','index']);
$router->get('/estudiantes/crear', ['EstudianteController','createForm']);
$router->post('/estudiantes/crear', ['EstudianteController','store']);
$router->get('/preguntas', ['PreguntaController','index']);
$router->get('/preguntas/crear', ['PreguntaController','createForm']);
$router->post('/preguntas/crear', ['PreguntaController','store']);
$router->get('/preguntas/editar', ['PreguntaController','editForm']);      // ?id=1
$router->post('/preguntas/editar', ['PreguntaController','update']);      // POST
$router->post('/preguntas/eliminar', ['PreguntaController','destroy']);   // POST
$router->get('/partidas', ['PartidaController','index']);

$router->get('/partidas/crear', ['PartidaController','createForm']);
$router->post('/partidas/crear', ['PartidaController','store']);

$router->get('/partidas/preguntas', ['PartidaController','preguntasForm']);  // ?id=PARTIDA
$router->post('/partidas/preguntas', ['PartidaController','preguntasSave']); // POST
$router->get('/unirse', ['ParticipacionController','joinForm']);
$router->post('/unirse', ['ParticipacionController','joinSubmit']);
$router->get('/sala', ['ParticipacionController','sala']);
$router->post('/partidas/iniciar', ['PartidaController','iniciar']);     // POST
$router->post('/partidas/finalizar', ['PartidaController','finalizar']); // POST
$router->get('/partidas/ranking', ['PartidaController','ranking']);      // ?id=...
$router->get('/quiz', ['QuizController','show']);
$router->post('/quiz/responder', ['QuizController','responder']);
$router->get('/quiz/fin', ['QuizController','fin']);
$router->get('/resultado', ['ResultadoController','show']);




