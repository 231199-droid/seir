<?php
declare(strict_types=1);

class ResultadoRepository {
  public function getRankingPartida(int $idPartida): array {
    $pdo = db();
    // Si no tienes vista, usamos SQL directo:
    $st = $pdo->prepare("
      SELECT p.alias,
             u.nombres,
             u.apellidos,
             COALESCE(SUM(r.puntaje_obtenido),0) AS puntaje_total,
             COUNT(r.id_respuesta) AS respuestas
      FROM participante p
      JOIN estudiante e ON e.id_usuario = p.id_estudiante
      JOIN usuario u ON u.id_usuario = e.id_usuario
      LEFT JOIN respuesta r ON r.id_participante = p.id_participante
      LEFT JOIN partida_pregunta pp ON pp.id = r.id_partida_pregunta
      WHERE p.id_partida = ?
      GROUP BY p.id_participante, p.alias, u.nombres, u.apellidos
      ORDER BY puntaje_total DESC, respuestas DESC, p.alias ASC
    ");
    $st->execute([$idPartida]);
    return $st->fetchAll();
  }
}
