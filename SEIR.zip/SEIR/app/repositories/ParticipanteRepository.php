<?php
declare(strict_types=1);

class ParticipanteRepository {

  public function findByPartidaAndEstudiante(int $idPartida, int $idEstudiante): ?array {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT id_participante, alias, fecha_union
      FROM participante
      WHERE id_partida = ? AND id_estudiante = ?
      LIMIT 1
    ");
    $st->execute([$idPartida, $idEstudiante]);
    $row = $st->fetch();
    return $row ?: null;
  }

  public function aliasExisteEnPartida(int $idPartida, string $alias): bool {
    $pdo = db();
    $st = $pdo->prepare("SELECT 1 FROM participante WHERE id_partida=? AND alias=? LIMIT 1");
    $st->execute([$idPartida, $alias]);
    return (bool)$st->fetch();
  }

  public function create(int $idPartida, int $idEstudiante, string $alias): int {
    $pdo = db();
    $st = $pdo->prepare("
      INSERT INTO participante (id_partida, id_estudiante, alias)
      VALUES (?, ?, ?)
    ");
    $st->execute([$idPartida, $idEstudiante, $alias]);
    return (int)$pdo->lastInsertId();
  }
}
