<?php
declare(strict_types=1);

class QuizRepository {

  public function getSiguientePregunta(int $idPartida, int $idParticipante): ?array {
    $pdo = db();

    // Trae la siguiente pregunta que aún no fue respondida por este participante
    $st = $pdo->prepare("
      SELECT pp.id AS id_partida_pregunta, pp.orden,
             q.id_pregunta, q.enunciado, q.dificultad
      FROM partida_pregunta pp
      JOIN pregunta q ON q.id_pregunta = pp.id_pregunta
      LEFT JOIN respuesta r
        ON r.id_partida_pregunta = pp.id AND r.id_participante = ?
      WHERE pp.id_partida = ?
        AND r.id_respuesta IS NULL
      ORDER BY pp.orden ASC
      LIMIT 1
    ");
    $st->execute([$idParticipante, $idPartida]);
    $row = $st->fetch();
    return $row ?: null;
  }

  public function getAlternativas(int $idPregunta): array {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT id_alternativa, texto
      FROM alternativa
      WHERE id_pregunta = ?
      ORDER BY id_alternativa ASC
    ");
    $st->execute([$idPregunta]);
    return $st->fetchAll();
  }

  public function insertRespuesta(int $idParticipante, int $idPartidaPregunta, int $idAlternativa, float $tiempo): void {
    $pdo = db();
    $st = $pdo->prepare("
      INSERT INTO respuesta (id_participante, id_partida_pregunta, id_alternativa, tiempo_respuesta)
      VALUES (?, ?, ?, ?)
    ");
    $st->execute([$idParticipante, $idPartidaPregunta, $idAlternativa, $tiempo]);
  }

  public function countRespondidas(int $idPartida, int $idParticipante): int {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT COUNT(*) c
      FROM respuesta r
      JOIN partida_pregunta pp ON pp.id = r.id_partida_pregunta
      WHERE pp.id_partida = ? AND r.id_participante = ?
    ");
    $st->execute([$idPartida, $idParticipante]);
    return (int)$st->fetch()['c'];
  }

  public function countTotalPreguntas(int $idPartida): int {
    $pdo = db();
    $st = $pdo->prepare("SELECT COUNT(*) c FROM partida_pregunta WHERE id_partida=?");
    $st->execute([$idPartida]);
    return (int)$st->fetch()['c'];
  }
}
