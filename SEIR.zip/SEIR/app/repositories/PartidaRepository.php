<?php
declare(strict_types=1);

class PartidaRepository {

  public function getAllByDocente(int $idDocente): array {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT id_partida, codigo, titulo, estado, tiempo_pregunta, fecha_inicio, fecha_fin, created_at
      FROM partida
      WHERE id_docente = ?
      ORDER BY created_at DESC
    ");
    $st->execute([$idDocente]);
    return $st->fetchAll();
  }

  public function createPartida(int $idDocente, string $codigo, string $titulo, int $tiempo): int {
    $pdo = db();
    $st = $pdo->prepare("
      INSERT INTO partida (codigo, titulo, estado, tiempo_pregunta, id_docente)
      VALUES (?, ?, 'CREADA', ?, ?)
    ");
    $st->execute([$codigo, $titulo, $tiempo, $idDocente]);
    return (int)$pdo->lastInsertId();
  }

  public function codigoExiste(string $codigo): bool {
    $pdo = db();
    $st = $pdo->prepare("SELECT 1 FROM partida WHERE codigo = ? LIMIT 1");
    $st->execute([$codigo]);
    return (bool)$st->fetch();
  }

  public function findById(int $idPartida, int $idDocente): ?array {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT id_partida, codigo, titulo, estado, tiempo_pregunta
      FROM partida
      WHERE id_partida = ? AND id_docente = ?
      LIMIT 1
    ");
    $st->execute([$idPartida, $idDocente]);
    $row = $st->fetch();
    return $row ?: null;
  }

  public function clearPreguntas(int $idPartida): void {
    $pdo = db();
    $st = $pdo->prepare("DELETE FROM partida_pregunta WHERE id_partida = ?");
    $st->execute([$idPartida]);
  }

  public function addPreguntaToPartida(int $idPartida, int $idPregunta, int $orden): void {
    $pdo = db();
    $st = $pdo->prepare("
      INSERT INTO partida_pregunta (id_partida, id_pregunta, orden)
      VALUES (?, ?, ?)
    ");
    $st->execute([$idPartida, $idPregunta, $orden]);
  }

  public function getPreguntasIds(int $idPartida): array {
    $pdo = db();
    $st = $pdo->prepare("
      SELECT id_pregunta, orden
      FROM partida_pregunta
      WHERE id_partida = ?
      ORDER BY orden ASC
    ");
    $st->execute([$idPartida]);
    return $st->fetchAll();
  }

  public function findByCodigo(string $codigo): ?array {
    $pdo = db();
    $st = $pdo->prepare("
        SELECT id_partida, codigo, titulo, estado, tiempo_pregunta, id_docente
        FROM partida
        WHERE codigo = ?
        LIMIT 1
    ");
    $st->execute([$codigo]);
    $row = $st->fetch();
    return $row ?: null;
  }
    public function countPreguntas(int $idPartida): int {
        $pdo = db();
        $st = $pdo->prepare("SELECT COUNT(*) c FROM partida_pregunta WHERE id_partida=?");
        $st->execute([$idPartida]);
        return (int)$st->fetch()['c'];
    }

    public function setEstadoIniciar(int $idPartida, int $idDocente): void {
        $pdo = db();
        $st = $pdo->prepare("
            UPDATE partida
            SET estado='EN_CURSO', fecha_inicio = NOW()
            WHERE id_partida=? AND id_docente=? AND estado='CREADA'
        ");
        $st->execute([$idPartida, $idDocente]);
    }

    public function setEstadoFinalizar(int $idPartida, int $idDocente): void {
        $pdo = db();
        $st = $pdo->prepare("
            UPDATE partida
            SET estado='FINALIZADA', fecha_fin = NOW()
            WHERE id_partida=? AND id_docente=? AND estado='EN_CURSO'
        ");
        $st->execute([$idPartida, $idDocente]);
    }

    public function getRanking(int $idPartida): array {
        $pdo = db();
        $st = $pdo->prepare("
            SELECT alias, nombres, apellidos, puntaje_total, respuestas_registradas
            FROM vw_ranking_partida
            WHERE id_partida = ?
            ORDER BY puntaje_total DESC, respuestas_registradas DESC, alias ASC
        ");
        $st->execute([$idPartida]);
        return $st->fetchAll();
    }
    public function getEstadoById(int $idPartida): ?string {
        $pdo = db();
        $st = $pdo->prepare("SELECT estado FROM partida WHERE id_partida=? LIMIT 1");
        $st->execute([$idPartida]);
        $row = $st->fetch();
        return $row ? (string)$row['estado'] : null;
    }


}
