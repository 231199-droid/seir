<?php
declare(strict_types=1);

class PreguntaRepository {

    public function getAllByDocente(int $idDocente): array {
        $pdo = db();
        $st = $pdo->prepare("
        SELECT id_pregunta, enunciado, dificultad, activo, created_at
        FROM pregunta
        WHERE id_docente = ?
        ORDER BY created_at DESC
        ");
        $st->execute([$idDocente]);
        return $st->fetchAll();
    }

    public function createPregunta(string $enunciado, string $dificultad, int $idDocente): int {
        $pdo = db();
        $st = $pdo->prepare("
        INSERT INTO pregunta (enunciado, dificultad, activo, id_docente)
        VALUES (?, ?, 1, ?)
        ");
        $st->execute([$enunciado, $dificultad, $idDocente]);
        return (int)$pdo->lastInsertId();
    }

    public function addAlternativa(int $idPregunta, string $texto, bool $esCorrecta): void {
        $pdo = db();
        $st = $pdo->prepare("
        INSERT INTO alternativa (id_pregunta, texto, es_correcta)
        VALUES (?, ?, ?)
        ");
        $st->execute([$idPregunta, $texto, $esCorrecta ? 1 : 0]);
    }

    public function getAlternativas(int $idPregunta): array {
        $pdo = db();
        $st = $pdo->prepare("
        SELECT id_alternativa, texto, es_correcta
        FROM alternativa
        WHERE id_pregunta = ?
        ORDER BY id_alternativa ASC
        ");
        $st->execute([$idPregunta]);
        return $st->fetchAll();
    }
    public function findById(int $idPregunta, int $idDocente): ?array {
        $pdo = db();
        $st = $pdo->prepare("
            SELECT id_pregunta, enunciado, dificultad, activo
            FROM pregunta
            WHERE id_pregunta = ? AND id_docente = ?
            LIMIT 1
        ");
        $st->execute([$idPregunta, $idDocente]);
        $row = $st->fetch();
        return $row ?: null;
    }

    public function updatePregunta(int $idPregunta, int $idDocente, string $enunciado, string $dificultad, int $activo): void {
        $pdo = db();
        $st = $pdo->prepare("
            UPDATE pregunta
            SET enunciado = ?, dificultad = ?, activo = ?
            WHERE id_pregunta = ? AND id_docente = ?
        ");
        $st->execute([$enunciado, $dificultad, $activo, $idPregunta, $idDocente]);
    }

    public function deleteAlternativas(int $idPregunta): void {
        $pdo = db();
        $st = $pdo->prepare("DELETE FROM alternativa WHERE id_pregunta = ?");
        $st->execute([$idPregunta]);
    }

    public function deletePregunta(int $idPregunta, int $idDocente): void {
        $pdo = db();
        $st = $pdo->prepare("DELETE FROM pregunta WHERE id_pregunta = ? AND id_docente = ?");
        $st->execute([$idPregunta, $idDocente]);
    }
      
}
