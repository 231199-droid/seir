<?php
declare(strict_types=1);

require_once APP_PATH . "/repositories/PartidaRepository.php";
require_once APP_PATH . "/repositories/PreguntaRepository.php";

class PartidaService {
  private PartidaRepository $repo;
  private PreguntaRepository $pregRepo;

  public function __construct() {
    $this->repo = new PartidaRepository();
    $this->pregRepo = new PreguntaRepository();
  }

  public function listar(int $idDocente): array {
    return $this->repo->getAllByDocente($idDocente);
  }

  private function generarCodigoUnico(): string {
    // SEIR-XXXXX (LAN friendly)
    for ($i=0; $i<10; $i++) {
      $code = "SEIR-" . str_pad((string)random_int(0, 99999), 5, "0", STR_PAD_LEFT);
      if (!$this->repo->codigoExiste($code)) return $code;
    }
    throw new Exception("No se pudo generar código, intenta de nuevo.");
  }

  public function crear(int $idDocente, array $data): void {
    $titulo = trim($data['titulo'] ?? '');
    $tiempo = (int)($data['tiempo_pregunta'] ?? 30);

    if ($titulo === '') throw new Exception("El título es obligatorio.");
    if ($tiempo < 5 || $tiempo > 300) throw new Exception("Tiempo por pregunta debe estar entre 5 y 300 segundos.");

    $codigo = $this->generarCodigoUnico();
    $this->repo->createPartida($idDocente, $codigo, $titulo, $tiempo);
  }

  public function formPreguntas(int $idDocente, int $idPartida): array {
    $partida = $this->repo->findById($idPartida, $idDocente);
    if (!$partida) throw new Exception("Partida no encontrada.");

    $banco = $this->pregRepo->getAllByDocente($idDocente);
    $seleccionadas = $this->repo->getPreguntasIds($idPartida); // id_pregunta + orden

    $mapOrden = [];
    foreach ($seleccionadas as $s) $mapOrden[(int)$s['id_pregunta']] = (int)$s['orden'];

    return [
      "partida" => $partida,
      "banco" => $banco,
      "mapOrden" => $mapOrden
    ];
  }

  public function guardarPreguntas(int $idDocente, int $idPartida, array $data): void {
    $partida = $this->repo->findById($idPartida, $idDocente);
    if (!$partida) throw new Exception("Partida no encontrada.");

    $seleccion = $data['sel'] ?? [];   // sel[id_pregunta] = "on"
    $ordenes   = $data['orden'] ?? []; // orden[id_pregunta] = 1..n

    if (empty($seleccion)) throw new Exception("Selecciona al menos 1 pregunta.");

    // armar lista (idPregunta, orden)
    $items = [];
    foreach ($seleccion as $idPreguntaStr => $_) {
      $idPregunta = (int)$idPreguntaStr;
      $orden = (int)($ordenes[$idPreguntaStr] ?? 0);
      if ($orden <= 0) throw new Exception("Cada pregunta seleccionada debe tener un orden > 0.");
      $items[] = ["id"=>$idPregunta, "orden"=>$orden];
    }

    // validar orden sin repetidos
    $ordList = array_map(fn($x)=>$x["orden"], $items);
    if (count($ordList) !== count(array_unique($ordList))) {
      throw new Exception("No repitas el orden. Debe ser 1,2,3...");
    }

    usort($items, fn($a,$b)=>$a["orden"] <=> $b["orden"]);

    $pdo = db();
    $pdo->beginTransaction();
    try {
      $this->repo->clearPreguntas($idPartida);
      foreach ($items as $it) {
        $this->repo->addPreguntaToPartida($idPartida, $it["id"], $it["orden"]);
      }
      $pdo->commit();
    } catch (Throwable $e) {
      $pdo->rollBack();
      throw $e;
    }
  }
    public function iniciar(int $idDocente, int $idPartida): void {
        $p = $this->repo->findById($idPartida, $idDocente);
        if (!$p) throw new Exception("Partida no encontrada.");
        if ($p['estado'] !== 'CREADA') throw new Exception("Solo se puede iniciar si está CREADA.");

        if ($this->repo->countPreguntas($idPartida) <= 0) {
            throw new Exception("Agrega preguntas antes de iniciar.");
        }

        $this->repo->setEstadoIniciar($idPartida, $idDocente);
    }

    public function finalizar(int $idDocente, int $idPartida): void {
        $p = $this->repo->findById($idPartida, $idDocente);
        if (!$p) throw new Exception("Partida no encontrada.");
        if ($p['estado'] !== 'EN_CURSO') throw new Exception("Solo se puede finalizar si está EN_CURSO.");

        $this->repo->setEstadoFinalizar($idPartida, $idDocente);
    }
    
    public function ranking(int $idDocente, int $idPartida): array {
        $p = $this->repo->findById($idPartida, $idDocente);
        if (!$p) throw new Exception("Partida no encontrada.");
        return $this->repo->getRanking($idPartida);
    }

}
