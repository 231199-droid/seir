<?php
declare(strict_types=1);

require_once APP_PATH . "/repositories/PartidaRepository.php";
require_once APP_PATH . "/repositories/ParticipanteRepository.php";

class ParticipacionService {
  private PartidaRepository $partidaRepo;
  private ParticipanteRepository $partRepo;

  public function __construct() {
    $this->partidaRepo = new PartidaRepository();
    $this->partRepo = new ParticipanteRepository();
  }

  public function unirse(int $idEstudiante, string $codigo, string $alias): array {
    $codigo = strtoupper(trim($codigo));
    $alias = trim($alias);

    if ($codigo === '' || $alias === '') {
      throw new Exception("Código y alias son obligatorios.");
    }
    if (mb_strlen($alias) > 60) {
      throw new Exception("Alias demasiado largo (máx 60).");
    }

    $partida = $this->partidaRepo->findByCodigo($codigo);
    if (!$partida) throw new Exception("Código de partida no existe.");

    if ($partida['estado'] === 'FINALIZADA') {
      throw new Exception("La partida ya finalizó.");
    }

    $idPartida = (int)$partida['id_partida'];

    // Si ya se unió antes, no vuelve a insertar
    $ya = $this->partRepo->findByPartidaAndEstudiante($idPartida, $idEstudiante);
    if ($ya) {
      return [
        "partida" => $partida,
        "participante" => [
          "id_participante" => (int)$ya["id_participante"],
          "alias" => $ya["alias"]
        ]
      ];
    }

    // Alias único por partida
    if ($this->partRepo->aliasExisteEnPartida($idPartida, $alias)) {
      throw new Exception("Ese alias ya está en uso en esta partida.");
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
      $idParticipante = $this->partRepo->create($idPartida, $idEstudiante, $alias);
      $pdo->commit();

      return [
        "partida" => $partida,
        "participante" => [
          "id_participante" => $idParticipante,
          "alias" => $alias
        ]
      ];
    } catch (Throwable $e) {
      $pdo->rollBack();
      throw $e;
    }
  }
}
