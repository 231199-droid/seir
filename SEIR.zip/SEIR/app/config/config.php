<?php
declare(strict_types=1);

define('BASE_PATH', dirname(__DIR__, 2));
define('APP_PATH', BASE_PATH . '/app');
define('VIEW_PATH', APP_PATH . '/views');
define('PUBLIC_PATH', BASE_PATH . '/public');

require_once APP_PATH . '/config/database.php';
require_once APP_PATH . '/core/Controller.php';
require_once APP_PATH . '/core/View.php';
require_once APP_PATH . '/core/Auth.php';
