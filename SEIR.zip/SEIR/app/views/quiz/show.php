<h2><?= htmlspecialchars($quiz['titulo']) ?></h2>
<p><strong>Alias:</strong> <?= htmlspecialchars($quiz['alias']) ?></p>
<p><strong>Progreso:</strong> <?= (int)$respondidas + 1 ?> / <?= (int)$total ?></p>

<hr>

<h3>Pregunta <?= (int)$p['orden'] ?></h3>
<p style="font-size:18px;"><?= htmlspecialchars($p['enunciado']) ?></p>

<form method="POST" action="/SEIR/public/quiz/responder" style="margin-top:14px;">
  <input type="hidden" name="id_partida_pregunta" value="<?= (int)$p['id_partida_pregunta'] ?>">

  <div style="display:grid; gap:10px; margin-top:12px;">
    <?php foreach ($alts as $a): ?>
      <label style="display:flex; gap:10px; align-items:center; padding:10px; border:1px solid #ddd; border-radius:10px;">
        <input type="radio" name="id_alternativa" value="<?= (int)$a['id_alternativa'] ?>" required>
        <span><?= htmlspecialchars($a['texto']) ?></span>
      </label>
    <?php endforeach; ?>
  </div>

  <div style="display:flex; gap:10px; margin-top:16px;">
    <button class="btn btn-primary" type="submit">Responder</button>
  </div>
  <div style="margin:10px 0; padding:10px; border:1px solid #ddd; border-radius:10px;">
  ⏱️ Tiempo restante: <strong id="timer"><?= (int)$tiempo_limite ?></strong> s
</div>
</form>
<script>
  let t = <?= (int)$tiempo_limite ?>;
  const el = document.getElementById('timer');
  const form = document.querySelector('form');

  const interval = setInterval(() => {
    t--;
    el.textContent = t;

    if (t <= 0) {
      clearInterval(interval);

      // Si no seleccionó nada, no enviamos (evitamos error).
      // Luego podemos mejorar para registrar "sin respuesta".
      const selected = form.querySelector('input[name="id_alternativa"]:checked');
      if (!selected) {
        alert("Tiempo terminado. No seleccionaste respuesta.");
        window.location.reload();
        return;
      }

      form.submit();
    }
  }, 1000);
</script>
