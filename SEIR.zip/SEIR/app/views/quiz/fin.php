<h2>Quiz finalizado</h2>

<p><strong>Partida:</strong> <?= htmlspecialchars($quiz['titulo']) ?></p>
<p><strong>Alias:</strong> <?= htmlspecialchars($quiz['alias']) ?></p>

<hr>

<p>Respondiste <strong><?= (int)$respondidas ?></strong> de <strong><?= (int)$total ?></strong> preguntas.</p>

<p style="margin-top:14px;">
  <a class="btn btn-primary" href="/SEIR/public/sala">Volver a sala</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Dashboard</a>
  <a class="btn btn-primary" href="/SEIR/public/resultado">Ver ranking</a>
</p>
