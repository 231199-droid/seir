<h2>Panel de control</h2>

<p>Bienvenido(a): <strong><?= htmlspecialchars($user['nombres']." ".$user['apellidos']) ?></strong></p>
<p>Rol: <strong><?= htmlspecialchars($user['rol']) ?></strong></p>

<hr>

<h3>Menú</h3>
<ul>
  <?php if ($user['rol'] === 'DOCENTE' || $user['rol'] === 'ADMIN'): ?>
    <li><a href="/SEIR/public/preguntas">Banco de preguntas</a></li>
    <li><a href="/SEIR/public/partidas">Partidas</a></li>
    <li><a href="/SEIR/public/estudiantes">Estudiantes</a></li>
  <?php endif; ?>
  <?php if ($user['rol'] === 'ESTUDIANTE'): ?>
    <li><a href="/SEIR/public/unirse">Unirse a partida</a></li>
  <?php endif; ?>

  <li><a href="/SEIR/public/logout">Cerrar sesión</a></li>
</ul>
