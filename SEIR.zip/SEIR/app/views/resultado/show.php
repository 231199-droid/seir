<h2>Resultados</h2>
<p><strong>Partida:</strong> <?= htmlspecialchars($quiz['titulo']) ?></p>
<p><strong>Tu alias:</strong> <?= htmlspecialchars($quiz['alias']) ?></p>

<hr>

<div style="overflow:auto;">
<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
  <thead>
    <tr>
      <th>N°</th>
      <th>Alias</th>
      <th>Nombre</th>
      <th>Puntaje</th>
      <th>Respuestas</th>
    </tr>
  </thead>
  <tbody>
  <?php $n=1; foreach ($ranking as $r): ?>
    <?php $esYo = ($r['alias'] === $quiz['alias']); ?>
    <tr style="<?= $esYo ? 'font-weight:700;background:#f3f3f3;' : '' ?>">
      <td><?= $n++ ?></td>
      <td><?= htmlspecialchars($r['alias']) ?></td>
      <td><?= htmlspecialchars($r['nombres'].' '.$r['apellidos']) ?></td>
      <td><?= htmlspecialchars($r['puntaje_total']) ?></td>
      <td><?= htmlspecialchars($r['respuestas']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<p style="margin-top:14px;">
  <a class="btn btn-primary" href="/SEIR/public/sala">Volver</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Dashboard</a>
</p>
