<h2>Iniciar sesión</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/login" class="row" style="margin-top:14px;">
  <div>
    <label>Usuario</label>
    <input name="username" placeholder="DNI o username" autocomplete="username" required>
  </div>

  <div>
    <label>Contraseña</label>
    <input type="password" name="password" placeholder="Contraseña" autocomplete="current-password" required>
  </div>

  <button class="btn btn-primary" type="submit">Entrar</button>
</form>
