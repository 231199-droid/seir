<h2>Nueva partida</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/partidas/crear" class="row" style="margin-top:14px;">
  <div>
    <label>Título</label>
    <input name="titulo" placeholder="Ej: Evaluación rápida" required>
  </div>

  <div>
    <label>Tiempo por pregunta (segundos)</label>
    <input type="number" name="tiempo_pregunta" value="30" min="5" max="300" required>
  </div>

  <p style="margin-top:6px;">
    ✅ El sistema generará automáticamente un <strong>código</strong> para que los estudiantes se unan.
  </p>

  <div style="display:flex; gap:10px; margin-top:10px;">
    <button class="btn btn-primary" type="submit">Crear</button>
    <a class="btn btn-link" href="/SEIR/public/partidas">Cancelar</a>
  </div>
</form>
