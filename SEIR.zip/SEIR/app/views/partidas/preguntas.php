<h2>Partida: <?= htmlspecialchars($partida['titulo']) ?></h2>
<p>Código: <strong><?= htmlspecialchars($partida['codigo']) ?></strong> | Tiempo/preg: <?= (int)$partida['tiempo_pregunta'] ?> s</p>

<?php if (!empty($ok)): ?>
  <div style="background:#e9fff0;border:1px solid #9be7b0;padding:10px;border-radius:10px;">
    <?= htmlspecialchars($ok) ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/partidas/preguntas" style="margin-top:14px;">
  <input type="hidden" name="id_partida" value="<?= (int)$partida['id_partida'] ?>">

  <p>Selecciona preguntas y asigna orden (1,2,3... sin repetir):</p>

  <div style="overflow:auto;">
  <table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
    <thead>
      <tr>
        <th>Sel</th>
        <th>Orden</th>
        <th>ID</th>
        <th>Enunciado</th>
        <th>Dificultad</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($banco as $q): 
      $idq = (int)$q['id_pregunta'];
      $checked = array_key_exists($idq, $mapOrden);
      $orden = $checked ? (int)$mapOrden[$idq] : '';
    ?>
      <tr>
        <td style="text-align:center;">
          <input type="checkbox" name="sel[<?= $idq ?>]" <?= $checked ? 'checked' : '' ?>>
        </td>
        <td style="width:90px;">
          <input type="number" name="orden[<?= $idq ?>]" value="<?= htmlspecialchars((string)$orden) ?>" min="1" style="width:80px;">
        </td>
        <td><?= $idq ?></td>
        <td><?= htmlspecialchars(mb_strimwidth($q['enunciado'], 0, 80, '...')) ?></td>
        <td><?= htmlspecialchars($q['dificultad']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>

  <div style="display:flex; gap:10px; margin-top:14px;">
    <button class="btn btn-primary" type="submit">Guardar preguntas</button>
    <a class="btn btn-link" href="/SEIR/public/partidas">Volver</a>
  </div>
</form>
