<h2>Ranking - Partida #<?= (int)$id_partida ?></h2>

<p><a class="btn btn-link" href="/SEIR/public/partidas">Volver</a></p>

<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
  <thead>
    <tr>
      <th>N°</th>
      <th>Alias</th>
      <th>Nombre</th>
      <th>Puntaje</th>
      <th>Respuestas</th>
    </tr>
  </thead>
  <tbody>
  <?php $n=1; foreach ($ranking as $r): ?>
    <tr>
      <td><?= $n++ ?></td>
      <td><?= htmlspecialchars($r['alias']) ?></td>
      <td><?= htmlspecialchars($r['nombres'].' '.$r['apellidos']) ?></td>
      <td><?= htmlspecialchars($r['puntaje_total']) ?></td>
      <td><?= htmlspecialchars($r['respuestas_registradas']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
