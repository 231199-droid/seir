<h2>Partidas</h2>

<?php if (!empty($ok)): ?>
  <div style="background:#e9fff0;border:1px solid #9be7b0;padding:10px;border-radius:10px;">
    <?= htmlspecialchars($ok) ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display:flex; gap:10px; margin-top:14px;">
  <a class="btn btn-primary" href="/SEIR/public/partidas/crear">+ Nueva partida</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Volver</a>
</div>

<div style="overflow:auto; margin-top:14px;">
<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
  <thead>
    <tr>
      <th>Código</th>
      <th>Título</th>
      <th>Estado</th>
      <th>Tiempo/preg</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($partidas as $p): ?>
    <tr>
      <td><strong><?= htmlspecialchars($p['codigo']) ?></strong></td>
      <td><?= htmlspecialchars($p['titulo']) ?></td>
      <td><?= htmlspecialchars($p['estado']) ?></td>
      <td><?= (int)$p['tiempo_pregunta'] ?> s</td>
      <td>
            <a class="btn btn-link" href="/SEIR/public/partidas/preguntas?id=<?= (int)$p['id_partida'] ?>">Preguntas</a>
            <a class="btn btn-link" href="/SEIR/public/partidas/ranking?id=<?= (int)$p['id_partida'] ?>">Ranking</a>
            <?php if ($p['estado'] === 'CREADA'): ?>
                <form method="POST" action="/SEIR/public/partidas/iniciar" style="display:inline;"
                    onsubmit="return confirm('¿Iniciar partida?');">
                <input type="hidden" name="id_partida" value="<?= (int)$p['id_partida'] ?>">
                <button class="btn btn-link" type="submit">Iniciar</button>
                </form>
            <?php endif; ?>

            <?php if ($p['estado'] === 'EN_CURSO'): ?>
                <form method="POST" action="/SEIR/public/partidas/finalizar" style="display:inline;"
                    onsubmit="return confirm('¿Finalizar partida?');">
                <input type="hidden" name="id_partida" value="<?= (int)$p['id_partida'] ?>">
                <button class="btn btn-link" type="submit">Finalizar</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
