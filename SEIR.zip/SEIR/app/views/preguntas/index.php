<h2>Banco de preguntas</h2>

<?php if (!empty($ok)): ?>
  <div style="background:#e9fff0;border:1px solid #9be7b0;padding:10px;border-radius:10px;">
    <?= htmlspecialchars($ok) ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display:flex; gap:10px; margin-top:14px; align-items:center;">
  <a class="btn btn-primary" href="/SEIR/public/preguntas/crear">+ Nueva pregunta</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Volver</a>
</div>

<div style="overflow:auto; margin-top:14px;">
<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
  <thead>
  <tr>
    <th style="width:70px;">N°</th>
    <th style="width:70px;">ID</th>
    <th>Enunciado</th>
    <th style="width:110px;">Dificultad</th>
    <th style="width:80px;">Activo</th>
    <th style="width:180px;">Creado</th>
    <th style="width:180px;">Acciones</th>
  </tr>
</thead>
<tbody>
<?php $n = 1; ?>
<?php foreach ($preguntas as $p): ?>
  <tr>
    <td><?= $n++ ?></td>
    <td><?= (int)$p['id_pregunta'] ?></td>
    <td><?= htmlspecialchars(mb_strimwidth($p['enunciado'], 0, 90, '...')) ?></td>
    <td><?= htmlspecialchars($p['dificultad']) ?></td>
    <td><?= $p['activo'] ? 'Sí' : 'No' ?></td>
    <td><?= htmlspecialchars($p['created_at']) ?></td>
    <td>
      <a class="btn btn-link" href="/SEIR/public/preguntas/editar?id=<?= (int)$p['id_pregunta'] ?>">Editar</a>

      <form method="POST" action="/SEIR/public/preguntas/eliminar" style="display:inline;"
            onsubmit="return confirm('¿Seguro que deseas eliminar esta pregunta?');">
        <input type="hidden" name="id_pregunta" value="<?= (int)$p['id_pregunta'] ?>">
        <button class="btn btn-link" type="submit">Eliminar</button>
      </form>
    </td>
  </tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
