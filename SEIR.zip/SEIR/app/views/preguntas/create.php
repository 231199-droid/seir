<h2>Nueva pregunta</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/preguntas/crear" style="margin-top:14px;">
  <div class="row">
    <div>
      <label>Enunciado</label>
      <textarea name="enunciado" placeholder="Escribe la pregunta..." required
        style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;min-height:90px;"></textarea>
    </div>

    <div>
      <label>Dificultad</label>
      <select name="dificultad" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;">
        <option value="FACIL">FÁCIL</option>
        <option value="MEDIA">MEDIA</option>
        <option value="DIFICIL">DIFÍCIL</option>
      </select>
    </div>
  </div>

  <hr style="margin:18px 0;">

  <h3>Alternativas</h3>
  <p style="margin-top:6px;">Escribe mínimo <strong>2</strong> y marca <strong>1</strong> como correcta.</p>

  <div style="display:grid; gap:10px; margin-top:10px;">
    <?php
      $labels = ['A','B','C','D'];
      for ($i=0; $i<4; $i++):
        $required = ($i < 2) ? 'required' : '';
    ?>
      <div style="display:grid; grid-template-columns: 40px 40px 1fr; gap:10px; align-items:center;">
        <div style="font-weight:700;"><?= $labels[$i] ?></div>

        <div title="Marcar como correcta" style="display:flex; justify-content:center;">
          <input type="radio" name="correcta" value="<?= $i ?>" required>
        </div>

        <input type="text" name="alt[<?= $i ?>]" placeholder="Alternativa <?= $labels[$i] ?>" <?= $required ?>>
      </div>
    <?php endfor; ?>
  </div>

  <div style="display:flex; gap:10px; margin-top:18px;">
    <button class="btn btn-primary" type="submit">Guardar</button>
    <a class="btn btn-link" href="/SEIR/public/preguntas">Cancelar</a>
  </div>
</form>
