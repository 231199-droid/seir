<h2>Editar pregunta</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/preguntas/editar" style="margin-top:14px;">
  <input type="hidden" name="id_pregunta" value="<?= (int)$p['id_pregunta'] ?>">

  <div class="row">
    <div>
      <label>Enunciado</label>
      <textarea name="enunciado" required
        style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;min-height:90px;"><?= htmlspecialchars($p['enunciado']) ?></textarea>
    </div>

    <div>
      <label>Dificultad</label>
      <select name="dificultad" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;">
        <?php foreach (['FACIL'=>'FÁCIL','MEDIA'=>'MEDIA','DIFICIL'=>'DIFÍCIL'] as $val=>$txt): ?>
          <option value="<?= $val ?>" <?= ($p['dificultad']===$val?'selected':'') ?>><?= $txt ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div style="margin-top:6px;">
      <label style="display:flex; gap:8px; align-items:center;">
        <input type="checkbox" name="activo" <?= ((int)$p['activo']===1?'checked':'') ?>>
        Activo
      </label>
    </div>
  </div>

  <hr style="margin:18px 0;">

  <h3>Alternativas</h3>
  <p>Marca cuál es la correcta:</p>

  <?php
    // mapear alternativas actuales a 4 slots A-D
    $slots = ['', '', '', ''];
    $correctIndex = 0;
    foreach ($alts as $i => $a) {
      if ($i < 4) {
        $slots[$i] = $a['texto'];
        if ((int)$a['es_correcta'] === 1) $correctIndex = $i;
      }
    }
    $labels = ['A','B','C','D'];
  ?>

  <div style="display:grid; gap:10px; margin-top:10px;">
    <?php for ($i=0; $i<4; $i++): ?>
      <div style="display:grid; grid-template-columns: 40px 40px 1fr; gap:10px; align-items:center;">
        <div style="font-weight:700;"><?= $labels[$i] ?></div>

        <div style="display:flex; justify-content:center;">
          <input type="radio" name="correcta" value="<?= $i ?>" <?= ($i===$correctIndex?'checked':'') ?> required>
        </div>

        <input type="text" name="alt[<?= $i ?>]" value="<?= htmlspecialchars($slots[$i]) ?>" placeholder="Alternativa <?= $labels[$i] ?>" <?= ($i<2?'required':'') ?>>
      </div>
    <?php endfor; ?>
  </div>

  <div style="display:flex; gap:10px; margin-top:18px;">
    <button class="btn btn-primary" type="submit">Guardar cambios</button>
    <a class="btn btn-link" href="/SEIR/public/preguntas">Cancelar</a>
  </div>
</form>
