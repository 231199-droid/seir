<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SEIR</title>
  <style>
    body{font-family:Arial;margin:0;background:#f5f5f5}
    .container{max-width:900px;margin:40px auto;background:#fff;padding:24px;border-radius:12px}
    .btn{padding:10px 14px;border:0;border-radius:8px;cursor:pointer}
    .btn-primary{background:#111;color:#fff}
    .btn-link{background:transparent;color:#111;text-decoration:underline}
    input{width:100%;padding:10px;border:1px solid #ddd;border-radius:8px}
    .row{display:grid;gap:12px}
    .error{background:#ffecec;border:1px solid #ffb3b3;color:#8a0000;padding:10px;border-radius:10px}
    .topbar{background:#111;color:#fff;padding:12px 18px}
    a{color:inherit}
  </style>
</head>
<body>
<div class="topbar">
  <strong>SEIR</strong>
  <?php if (Auth::check()): ?>
    <span style="float:right;">
      <?= htmlspecialchars(Auth::user()['username']) ?> |
      <a href="/SEIR/public/logout">Salir</a>
    </span>
  <?php endif; ?>
</div>
<div class="container">
