<h2>Estudiantes</h2>

<?php if (!empty($ok)): ?>
  <div style="background:#e9fff0;border:1px solid #9be7b0;padding:10px;border-radius:10px;">
    <?= htmlspecialchars($ok) ?>
  </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<p style="margin-top:14px;">
  <a class="btn btn-primary" href="/SEIR/public/estudiantes/crear">+ Registrar estudiante</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Volver</a>
</p>

<table border="1" cellpadding="10" cellspacing="0" style="width:100%; border-collapse:collapse;">
  <thead>
    <tr>
      <th>DNI</th>
      <th>Nombres</th>
      <th>Apellidos</th>
      <th>Grado</th>
      <th>Sección</th>
      <th>Username</th>
      <th>Estado</th>
      <th>Creado</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($estudiantes as $e): ?>
    <tr>
      <td><?= htmlspecialchars($e['dni']) ?></td>
      <td><?= htmlspecialchars($e['nombres']) ?></td>
      <td><?= htmlspecialchars($e['apellidos']) ?></td>
      <td><?= htmlspecialchars($e['grado']) ?></td>
      <td><?= htmlspecialchars($e['seccion']) ?></td>
      <td><?= htmlspecialchars($e['username']) ?></td>
      <td><?= htmlspecialchars($e['estado']) ?></td>
      <td><?= htmlspecialchars($e['created_at']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
