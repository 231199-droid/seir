<h2>Registrar estudiante</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/estudiantes/crear" class="row" style="margin-top:14px;">
  <div>
    <label>DNI (será el username)</label>
    <input name="dni" placeholder="Ej: 70000001" required>
  </div>

  <div>
    <label>Nombres</label>
    <input name="nombres" placeholder="Ej: Ana" required>
  </div>

  <div>
    <label>Apellidos</label>
    <input name="apellidos" placeholder="Ej: Pérez" required>
  </div>

  <div>
    <label>Grado</label>
    <input name="grado" placeholder="Ej: 5to" required>
  </div>

  <div>
    <label>Sección</label>
    <input name="seccion" placeholder="Ej: A" required>
  </div>

  <p style="margin:8px 0 0 0;">
    ✅ El sistema asignará: <strong>username = DNI</strong> y <strong>clave inicial = DNI</strong>
  </p>

  <div style="display:flex; gap:10px; margin-top:10px;">
    <button class="btn btn-primary" type="submit">Guardar</button>
    <a class="btn btn-link" href="/SEIR/public/estudiantes">Cancelar</a>
  </div>
</form>
