<h2>Sala de espera</h2>

<p><strong>Partida:</strong> <?= htmlspecialchars($quiz['titulo']) ?></p>
<p><strong>Código:</strong> <?= htmlspecialchars($quiz['codigo']) ?></p>
<p><strong>Alias:</strong> <?= htmlspecialchars($quiz['alias']) ?></p>

<hr>

<p><strong>Estado:</strong> <?= htmlspecialchars($quiz['estado']) ?></p>

<?php if ($quiz['estado'] === 'CREADA'): ?>
  <p>⏳ Espera a que el docente inicie la partida.</p>
<?php elseif ($quiz['estado'] === 'FINALIZADA'): ?>
  <p>✅ La partida finalizó. (Luego mostraremos resultados aquí.)</p>
<?php endif; ?>


<p style="margin-top:14px;">
  <a class="btn btn-primary" href="/SEIR/public/sala">Actualizar</a>
  <a class="btn btn-link" href="/SEIR/public/dashboard">Salir</a>
</p>
