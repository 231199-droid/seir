<h2>Unirse a una partida</h2>

<?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" action="/SEIR/public/unirse" class="row" style="margin-top:14px;">
  <div>
    <label>Código de partida</label>
    <input name="codigo" placeholder="Ej: SEIR-12345" required>
  </div>

  <div>
    <label>Alias</label>
    <input name="alias" placeholder="Ej: Ana01" required>
  </div>

  <button class="btn btn-primary" type="submit">Unirme</button>

  <a class="btn btn-link" href="/SEIR/public/dashboard">Volver</a>
</form>
