<?php
declare(strict_types=1);

class View {
  public static function render(string $view, array $data = []): void {
    extract($data);
    require VIEW_PATH . "/layout/header.php";
    require VIEW_PATH . "/$view.php";
    require VIEW_PATH . "/layout/footer.php";
  }
}
