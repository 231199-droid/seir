<?php
declare(strict_types=1);

class Auth {
  public static function start(): void {
    if (session_status() === PHP_SESSION_NONE) {
      session_start();
    }
  }

  public static function login(array $user): void {
    self::start();
    $_SESSION['user'] = [
      'id_usuario' => (int)$user['id_usuario'],
      'username'   => $user['username'],
      'nombres'    => $user['nombres'],
      'apellidos'  => $user['apellidos'],
      'rol'        => $user['rol'] ?? 'USER' // ADMIN / DOCENTE / ESTUDIANTE
    ];
  }

  public static function user(): ?array {
    self::start();
    return $_SESSION['user'] ?? null;
  }

  public static function check(): bool {
    return self::user() !== null;
  }

  public static function requireLogin(): void {
    if (!self::check()) {
      header("Location: /SEIR/public/"); exit;
    }
  }

  public static function logout(): void {
    self::start();
    session_unset();
    session_destroy();
  }
}
