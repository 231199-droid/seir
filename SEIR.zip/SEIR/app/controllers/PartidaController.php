<?php
declare(strict_types=1);

require_once APP_PATH . "/services/PartidaService.php";

class PartidaController extends Controller {

  private function requireDocenteAdmin(): void {
    Auth::requireLogin();
    $u = Auth::user();
    if (!in_array($u['rol'], ['DOCENTE','ADMIN'], true)) {
      http_response_code(403);
      echo "403 - No autorizado";
      exit;
    }
  }

  public function index(): void {
    $this->requireDocenteAdmin();
    $u = Auth::user();
    $service = new PartidaService();

    $this->view("partidas/index", [
      "partidas" => $service->listar((int)$u['id_usuario']),
      "ok" => $_GET["ok"] ?? "",
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function createForm(): void {
    $this->requireDocenteAdmin();
    $this->view("partidas/create", [
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function store(): void {
    $this->requireDocenteAdmin();
    $u = Auth::user();

    try {
      $service = new PartidaService();
      $service->crear((int)$u['id_usuario'], $_POST);
      $this->redirect("/SEIR/public/partidas?ok=" . urlencode("Partida creada. Ahora agrega preguntas."));
    } catch (Throwable $e) {
      $this->redirect("/SEIR/public/partidas/crear?error=" . urlencode($e->getMessage()));
    }
  }

  public function preguntasForm(): void {
    $this->requireDocenteAdmin();
    $u = Auth::user();
    $id = (int)($_GET["id"] ?? 0);

    try {
      $service = new PartidaService();
      $data = $service->formPreguntas((int)$u['id_usuario'], $id);

      $this->view("partidas/preguntas", [
        "partida" => $data["partida"],
        "banco" => $data["banco"],
        "mapOrden" => $data["mapOrden"],
        "error" => $_GET["error"] ?? "",
        "ok" => $_GET["ok"] ?? ""
      ]);
    } catch (Throwable $e) {
      $this->redirect("/SEIR/public/partidas?error=" . urlencode($e->getMessage()));
    }
  }

    public function preguntasSave(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_POST["id_partida"] ?? 0);

        try {
        $service = new PartidaService();
        $service->guardarPreguntas((int)$u['id_usuario'], $id, $_POST);
        $this->redirect("/SEIR/public/partidas/preguntas?id=$id&ok=" . urlencode("Preguntas guardadas."));
        } catch (Throwable $e) {
        $this->redirect("/SEIR/public/partidas/preguntas?id=$id&error=" . urlencode($e->getMessage()));
        }
    }
    public function iniciar(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_POST['id_partida'] ?? 0);

        try {
            (new PartidaService())->iniciar((int)$u['id_usuario'], $id);
            $this->redirect("/SEIR/public/partidas?ok=" . urlencode("Partida iniciada."));
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/partidas?error=" . urlencode($e->getMessage()));
        }
    }

    public function finalizar(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_POST['id_partida'] ?? 0);

        try {
            (new PartidaService())->finalizar((int)$u['id_usuario'], $id);
            $this->redirect("/SEIR/public/partidas?ok=" . urlencode("Partida finalizada."));
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/partidas?error=" . urlencode($e->getMessage()));
        }
    }

    public function ranking(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_GET['id'] ?? 0);

        try {
            $service = new PartidaService();
            $rows = $service->ranking((int)$u['id_usuario'], $id);
            $this->view("partidas/ranking", [
            "ranking" => $rows,
            "id_partida" => $id
            ]);
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/partidas?error=" . urlencode($e->getMessage()));
        }
    }

}
