<?php
declare(strict_types=1);

require_once APP_PATH . "/repositories/ResultadoRepository.php";

class ResultadoController extends Controller {

  private function requireEstudiante(): void {
    Auth::requireLogin();
    $u = Auth::user();
    if (($u['rol'] ?? '') !== 'ESTUDIANTE') {
      http_response_code(403);
      echo "403 - Solo estudiantes";
      exit;
    }
  }

  public function show(): void {
    $this->requireEstudiante();
    Auth::start();
    $quiz = $_SESSION['quiz'] ?? null;

    if (!$quiz) {
      $this->redirect("/SEIR/public/unirse?error=" . urlencode("Primero debes unirte a una partida."));
    }

    $ranking = (new ResultadoRepository())->getRankingPartida((int)$quiz['id_partida']);

    $this->view("resultado/show", [
      "quiz" => $quiz,
      "ranking" => $ranking
    ]);
  }
}
