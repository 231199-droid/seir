<?php
declare(strict_types=1);

require_once APP_PATH . "/services/AuthService.php";

class AuthController extends Controller {

  public function loginForm(): void {
    // si ya está logueado, al dashboard
    if (Auth::check()) {
      $this->redirect("/SEIR/public/dashboard");
    }

    $this->view("auth/login", [
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function login(): void {
    try {
      $service = new AuthService();

      $username = $_POST["username"] ?? "";
      $password = $_POST["password"] ?? "";

      $userSession = $service->login($username, $password);
      Auth::login($userSession);

      $this->redirect("/SEIR/public/dashboard");

    } catch (Throwable $e) {
      $msg = urlencode($e->getMessage());
      $this->redirect("/SEIR/public/?error=$msg");
    }
  }

  public function dashboard(): void {
    Auth::requireLogin();

    $user = Auth::user();
    $this->view("dashboard/index", ["user" => $user]);
  }

  public function logout(): void {
    Auth::logout();
    $this->redirect("/SEIR/public/");
  }
}
