<?php
declare(strict_types=1);

require_once APP_PATH . "/services/EstudianteService.php";

class EstudianteController extends Controller {

  private function requireDocenteAdmin(): void {
    Auth::requireLogin();
    $u = Auth::user();
    if (!in_array($u['rol'], ['DOCENTE','ADMIN'], true)) {
      http_response_code(403);
      echo "403 - No autorizado";
      exit;
    }
  }

  public function index(): void {
    $this->requireDocenteAdmin();
    $service = new EstudianteService();

    $this->view("estudiantes/index", [
      "estudiantes" => $service->listar(),
      "ok" => $_GET["ok"] ?? "",
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function createForm(): void {
    $this->requireDocenteAdmin();
    $this->view("estudiantes/create", [
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function store(): void {
    $this->requireDocenteAdmin();

    try {
      $service = new EstudianteService();
      $service->registrar($_POST);

      $this->redirect("/SEIR/public/estudiantes?ok=" . urlencode("Estudiante registrado. Usuario=DNI, clave inicial=DNI"));
    } catch (Throwable $e) {
      $this->redirect("/SEIR/public/estudiantes/crear?error=" . urlencode($e->getMessage()));
    }
  }
}
