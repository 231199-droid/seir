<?php
declare(strict_types=1);

require_once APP_PATH . "/repositories/QuizRepository.php";
require_once APP_PATH . "/repositories/PartidaRepository.php";

class QuizController extends Controller {

    private function requireEstudiante(): void {
        Auth::requireLogin();
        $u = Auth::user();
        if (($u['rol'] ?? '') !== 'ESTUDIANTE') {
        http_response_code(403);
        echo "403 - Solo estudiantes";
        exit;
        }
    }

    private function getQuizSession(): array {
        Auth::start();
        $quiz = $_SESSION['quiz'] ?? null;
        if (!$quiz) {
        $this->redirect("/SEIR/public/unirse?error=" . urlencode("Primero debes unirte a una partida."));
        }
        return $quiz;
    }

    public function show(): void {
        $this->requireEstudiante();
        $quiz = $this->getQuizSession();

        // Validar estado actual
        $partidaRepo = new PartidaRepository();
        $estado = $partidaRepo->getEstadoById((int)$quiz['id_partida']);
        if ($estado === 'FINALIZADA') $this->redirect("/SEIR/public/quiz/fin");
        if ($estado !== 'EN_CURSO')  $this->redirect("/SEIR/public/sala");

        // Leer tiempo por pregunta desde la BD
        $pdo = db();
        $st = $pdo->prepare("SELECT tiempo_pregunta FROM partida WHERE id_partida=? LIMIT 1");
        $st->execute([(int)$quiz['id_partida']]);
        $tiempo_limite = (int)(($st->fetch()['tiempo_pregunta'] ?? 30));

        $repo = new QuizRepository();
        $sig = $repo->getSiguientePregunta((int)$quiz['id_partida'], (int)$quiz['id_participante']);

        if (!$sig) {
            $this->redirect("/SEIR/public/quiz/fin");
        }

        $alts = $repo->getAlternativas((int)$sig['id_pregunta']);

        // progreso
        $respondidas = $repo->countRespondidas((int)$quiz['id_partida'], (int)$quiz['id_participante']);
        $total = $repo->countTotalPreguntas((int)$quiz['id_partida']);

        // Guardar "inicio" por pregunta (NO se reinicia si recarga)
        Auth::start();
        if (!isset($_SESSION['quiz_timer'])) $_SESSION['quiz_timer'] = [];

        $idPP = (int)$sig['id_partida_pregunta'];
        if (!isset($_SESSION['quiz_timer'][$idPP])) {
            $_SESSION['quiz_timer'][$idPP] = microtime(true);
        }

        $this->view("quiz/show", [
            "quiz" => $quiz,
            "p" => $sig,
            "alts" => $alts,
            "respondidas" => $respondidas,
            "total" => $total,
            "tiempo_limite" => $tiempo_limite
        ]);
    }


    public function responder(): void {
        $this->requireEstudiante();
        $quiz = $this->getQuizSession();

        $idPartidaPregunta = (int)($_POST['id_partida_pregunta'] ?? 0);
        $idAlternativa = (int)($_POST['id_alternativa'] ?? 0);

        if ($idPartidaPregunta <= 0 || $idAlternativa <= 0) {
        $this->redirect("/SEIR/public/quiz?error=" . urlencode("Selecciona una alternativa."));
        }

        Auth::start();
        if (!isset($_SESSION['quiz_timer'])) $_SESSION['quiz_timer'] = [];

        $inicio = $_SESSION['quiz_timer'][$idPartidaPregunta] ?? microtime(true);
        $tiempo = microtime(true) - (float)$inicio;
        if ($tiempo < 0) $tiempo = 0;

        // ya no necesitamos el timer de esa pregunta
        unset($_SESSION['quiz_timer'][$idPartidaPregunta]);


        try {
        (new QuizRepository())->insertRespuesta(
            (int)$quiz['id_participante'],
            $idPartidaPregunta,
            $idAlternativa,
            (float)$tiempo
        );

        $this->redirect("/SEIR/public/quiz");
        } catch (Throwable $e) {
        // si intenta responder 2 veces, chocará con UNIQUE
        $this->redirect("/SEIR/public/quiz?error=" . urlencode("Respuesta ya registrada o inválida."));
        }
    }

    public function fin(): void {
        $this->requireEstudiante();
        $quiz = $this->getQuizSession();

        $repo = new QuizRepository();
        $respondidas = $repo->countRespondidas((int)$quiz['id_partida'], (int)$quiz['id_participante']);
        $total = $repo->countTotalPreguntas((int)$quiz['id_partida']);

        $this->view("quiz/fin", [
        "quiz" => $quiz,
        "respondidas" => $respondidas,
        "total" => $total
        ]);
    }
}
