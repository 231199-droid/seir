<?php
declare(strict_types=1);

require_once APP_PATH . "/services/PreguntaService.php";

class PreguntaController extends Controller {

    private function requireDocenteAdmin(): void {
        Auth::requireLogin();
        $u = Auth::user();
        if (!in_array($u['rol'], ['DOCENTE','ADMIN'], true)) {
        http_response_code(403);
        echo "403 - No autorizado";
        exit;
        }
    }

    public function index(): void {
        $this->requireDocenteAdmin();
        $service = new PreguntaService();
        $u = Auth::user();

        $this->view("preguntas/index", [
        "preguntas" => $service->listar((int)$u['id_usuario']),
        "ok" => $_GET["ok"] ?? "",
        "error" => $_GET["error"] ?? ""
        ]);
    }

    public function createForm(): void {
        $this->requireDocenteAdmin();
        $this->view("preguntas/create", [
        "error" => $_GET["error"] ?? ""
        ]);
    }

    public function store(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();

        try {
        $service = new PreguntaService();
        $service->crear((int)$u['id_usuario'], $_POST);

        $this->redirect("/SEIR/public/preguntas?ok=" . urlencode("Pregunta creada correctamente."));
        } catch (Throwable $e) {
        $this->redirect("/SEIR/public/preguntas/crear?error=" . urlencode($e->getMessage()));
        }
    }
    public function editForm(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) { $this->redirect("/SEIR/public/preguntas?error=" . urlencode("ID inválido")); }

        try {
            $service = new PreguntaService();
            $data = $service->obtener((int)$u['id_usuario'], $id);

            $this->view("preguntas/edit", [
            "p" => $data["pregunta"],
            "alts" => $data["alternativas"],
            "error" => $_GET["error"] ?? ""
            ]);
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/preguntas?error=" . urlencode($e->getMessage()));
        }
    }

    public function update(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_POST['id_pregunta'] ?? 0);
        if ($id <= 0) { $this->redirect("/SEIR/public/preguntas?error=" . urlencode("ID inválido")); }

        try {
            $service = new PreguntaService();
            $service->actualizar((int)$u['id_usuario'], $id, $_POST);
            $this->redirect("/SEIR/public/preguntas?ok=" . urlencode("Pregunta actualizada."));
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/preguntas/editar?id=$id&error=" . urlencode($e->getMessage()));
        }
    }

    public function destroy(): void {
        $this->requireDocenteAdmin();
        $u = Auth::user();
        $id = (int)($_POST['id_pregunta'] ?? 0);

        try {
            $service = new PreguntaService();
            $service->eliminar((int)$u['id_usuario'], $id);
            $this->redirect("/SEIR/public/preguntas?ok=" . urlencode("Pregunta eliminada."));
        } catch (Throwable $e) {
            $this->redirect("/SEIR/public/preguntas?error=" . urlencode($e->getMessage()));
        }
    }

}
