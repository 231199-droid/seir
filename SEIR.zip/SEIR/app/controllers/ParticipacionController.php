<?php
declare(strict_types=1);

require_once APP_PATH . "/services/ParticipacionService.php";

class ParticipacionController extends Controller {

  private function requireEstudiante(): void {
    Auth::requireLogin();
    $u = Auth::user();
    if ($u['rol'] !== 'ESTUDIANTE') {
      http_response_code(403);
      echo "403 - Solo estudiantes";
      exit;
    }
  }

  public function joinForm(): void {
    $this->requireEstudiante();
    $this->view("participacion/join", [
      "error" => $_GET["error"] ?? ""
    ]);
  }

  public function joinSubmit(): void {
    $this->requireEstudiante();
    $u = Auth::user();

    try {
      $service = new ParticipacionService();
      $data = $service->unirse((int)$u['id_usuario'], $_POST['codigo'] ?? '', $_POST['alias'] ?? '');

      Auth::start();
      $_SESSION['quiz'] = [
        "id_partida" => (int)$data["partida"]["id_partida"],
        "codigo" => $data["partida"]["codigo"],
        "titulo" => $data["partida"]["titulo"],
        "estado" => $data["partida"]["estado"],
        "id_participante" => (int)$data["participante"]["id_participante"],
        "alias" => $data["participante"]["alias"]
      ];

      $this->redirect("/SEIR/public/sala");
    } catch (Throwable $e) {
      $this->redirect("/SEIR/public/unirse?error=" . urlencode($e->getMessage()));
    }
  }

  public function sala(): void {
    
    $this->requireEstudiante();
    Auth::start();
    $quiz = $_SESSION['quiz'] ?? null;

    if (!$quiz) {
      $this->redirect("/SEIR/public/unirse?error=" . urlencode("Primero debes unirte a una partida."));
    }
    require_once APP_PATH . "/repositories/PartidaRepository.php";
    $estado = (new PartidaRepository())->getEstadoById((int)$quiz['id_partida']);
    $quiz['estado'] = $estado ?? $quiz['estado'];
    $_SESSION['quiz']['estado'] = $quiz['estado'];

    // Si ya inició, mandamos a /quiz (lo creamos en el siguiente paso)
    if ($quiz['estado'] === 'EN_CURSO') {
        $this->redirect("/SEIR/public/quiz");
    }
    $this->view("participacion/sala", [
      "quiz" => $quiz
    ]);
  }
}
